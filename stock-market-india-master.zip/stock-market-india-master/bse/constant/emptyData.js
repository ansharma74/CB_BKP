module.exports = {
  emptyCompanyInfo: {
    timeValue: '',
    previousClose: 0,
    open: 0,
    high: 0,
    low: 0,
    ltp: 0,
    latestValue: 0,
    securityId: 0,
    groupIndex: 0,
    faceValue: 0,
    securityCode: '',
    isin: '',
    industry: '',
    pointChange: 0,
    percChange: 0
  }
};
