export { default as useHistoricalData } from './useHistoricalData.js';
