export const QUERY_TERM = 'QUERY_TERM';
export const START_FETCH = 'START_FETCH';
export const FETCH_SUCCESS = 'FETCH_SUCCESS';
export const FETCH_ERROR = 'FETCH_ERROR';
export const ACTIVE_STOCK = 'ACTIVE_STOCK';
export const DELETE_STOCK = 'DELETE_STOCK';
export const TOGGLE_MODAL = 'TOGGLE_MODAL';
