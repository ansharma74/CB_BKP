export { default as News } from './news.js';
