export { default as CompanyDescription } from './company-description.js';
