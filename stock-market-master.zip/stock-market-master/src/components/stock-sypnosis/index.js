export { default as StockSypnosis } from './stock-sypnosis.js';
