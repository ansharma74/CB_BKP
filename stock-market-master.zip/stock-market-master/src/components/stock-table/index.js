export { default as StockTable } from './stock-table.js';
