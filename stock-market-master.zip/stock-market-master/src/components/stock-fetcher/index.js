export { default as StockFetcher } from './stock-fetcher.js';
