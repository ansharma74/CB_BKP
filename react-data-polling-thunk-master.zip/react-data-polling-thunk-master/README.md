Example of Short Polling with React, Redux and Thunk  

More details here https://medium.freecodecamp.org/how-to-implement-data-polling-with-react-redux-and-thunk-33cd1e47f89c
