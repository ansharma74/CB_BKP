.. _movingaverage:

##############
Moving Average
##############

*Moving Averages* are implemented in ``finquant.moving_average``.

.. automodule:: finquant.moving_average
    :members:
