.. _returns:

############################
Daily and Historical Returns
############################

Returns are implemented in ``finquant.returns``.

.. automodule:: finquant.returns
    :members:
