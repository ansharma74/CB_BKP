####################################################
# for now, the corresponding module in finquant is #
# tested through portfolio                         #
####################################################
